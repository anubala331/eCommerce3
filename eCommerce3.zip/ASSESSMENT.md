
# Marks 92/100
## Proper use of VSTS/Git: 20/20%
Contributions by all group members on git
## Correct and complete SQLServer/EF6 implementation: 20%: 18/20%
There are tables that have relationships that could be modeled in a way that allows you to do the joins automatically (eg. every cart has a user id). Refer to slides on modelling relationships in EFcore (one-to-one, one-to-many etc)
## Correct and complete ASP.NETCore API endpoints: 30% 24/30%
1. All endpoint CRUD methods implemented. 
2. No endpoint implemented for user authentication. This is a key requirement that you will have to address for your final application to work.
3. As mentioned in assignment 1, adequate session handling was not done to protect endpoints that could be possibly exposed to unauthorized users.
## Full suite of Postman tests: 30/30%