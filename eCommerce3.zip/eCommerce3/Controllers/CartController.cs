﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using eCommerce3.Models;
using eCommerce3.CartData;
using System;

namespace eCommerce3.Controllers
{

    [ApiController]
    public class CartController : ControllerBase
    {
        private ICartData _CartData;
        public CartController(ICartData CartData)
        {
            _CartData = CartData;
        }
        [HttpGet]
        [Route("api/[controller]")]
        public IActionResult GetCarts()
        {
            return Ok(_CartData.GetCarts());
        }
        [HttpGet]
        [Route("api/[controller]/{id}")]
        public IActionResult GetCart(Guid id)
        {
            var Cart = _CartData.GetCart(id);
            if (Cart != null)
            {
                return Ok(_CartData.GetCart(id));
            }
            return NotFound($"Cart with id:{id} was not found");
        }
        [HttpPost]
        [Route("api/[controller]")]
        public CreatedResult AddCart(CartModel CartModel)
        {
            _CartData.AddCart(CartModel);
            return Created(HttpContext.Request.Scheme + "://" + HttpContext.Request.Host + HttpContext.Request.Path + "/" + CartModel.Id, CartModel);

        }

        [HttpDelete]
        [Route("api/[controller]/{id}")]
        public IActionResult DeleteCart(Guid id)
        {
            var Cart = _CartData.GetCart(id);
            if (Cart != null)
            {
                _CartData.DeleteCart(Cart);
                return Ok("Deleted cart with id:" + id);
            }
            return NotFound($"Cart with id:{id} was not found");

        }
        [HttpPut]
        [Route("api/[controller]/{id}")]
        public IActionResult UpdateCart(Guid id, CartModel CartModel)
        {
            var existingCart = _CartData.GetCart(id);
            if (existingCart != null)
            {
                CartModel.Id = existingCart.Id;
                _CartData.EditCart(CartModel);
                return Ok(CartModel);
            }
            return NotFound($"Cart with id:{id} was not found");

        }
    }
}
