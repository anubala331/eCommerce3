﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using eCommerce3.Models;
using eCommerce3.CartData;
using System;

namespace eCommerce3.Controllers
{

    [ApiController]
    public class CartProductController : ControllerBase
    {
        private ICartProductData _CartProductData;
        public CartProductController(ICartProductData CartData)
        {
            _CartProductData = CartData;
        }
        [HttpGet]
        [Route("api/[controller]")]
        public IActionResult GetCartProducts()
        {
            return Ok(_CartProductData.GetCartProducts());
        }
        [HttpGet]
        [Route("api/[controller]/{id}")]
        public IActionResult GetCartProduct(Guid id)
        {
            var Cart = _CartProductData.GetCartProduct(id);
            if (Cart != null)
            {
                return Ok(_CartProductData.GetCartProduct(id));
            }
            return NotFound($"Cart Product with id:{id} was not found");
        }
        [HttpPost]
        [Route("api/[controller]")]
        public CreatedResult AddCartProduct(CartProductModel CartProductModel)
        {
            Console.WriteLine("Going to Add Cart Product");
            _CartProductData.AddCartProduct(CartProductModel);
            return Created(HttpContext.Request.Scheme + "://" + HttpContext.Request.Host + HttpContext.Request.Path + "/" + CartProductModel.Id, CartProductModel);

        }

        [HttpDelete]
        [Route("api/[controller]/{id}")]
        public IActionResult DeleteCartProduct(Guid id)
        {
            var CartProduct = _CartProductData.GetCartProduct(id);
            if (CartProduct != null)
            {
                _CartProductData.DeleteCartProduct(CartProduct);
                return Ok("Deleted cart product with id:" + id);
            }
            return NotFound($"Cart Product with id:{id} was not found");

        }
        [HttpPut]
        [Route("api/[controller]/{id}")]
        public IActionResult UpdateCartProduct(Guid id, CartProductModel CartProductModel)
        {
            var existingCartProduct = _CartProductData.GetCartProduct(id);
            if (existingCartProduct != null)
            {
                CartProductModel.Id = existingCartProduct.Id;
                _CartProductData.EditCartProduct(CartProductModel);
                return Ok(CartProductModel);
            }
            return NotFound($"Cart Product with id:{id} was not found");

        }
    }
}
