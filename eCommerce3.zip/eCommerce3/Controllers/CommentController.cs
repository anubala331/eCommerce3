﻿using Microsoft.AspNetCore.Mvc;
using eCommerce3.Models;
using System.Linq;
using Microsoft.EntityFrameworkCore;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace eCommerce3.Controllers
{
    [ApiController]
    public class CommentController : ControllerBase
    {
        private IComment _comments;
        public CommentController(IComment comment)
        {
            _comments = comment;
        }
        [HttpGet]
        [Route("api/[controller]")]
        public IActionResult GetAllComments()
        {
            return Ok(_comments.GetAllComments());
        }
        [HttpGet]
        [Route("api/[controller]/{id}")]
        public IActionResult GetComment(Guid id)
        {
            var comment = _comments.GetComment(id);
            if (comment != null)
            {
                return Ok(_comments.GetComment(id));
            }
            return NotFound($"Comment with id:{id} was not found");
        }
        [HttpPost]
        [Route("api/[controller]")]
        public CreatedResult AddComment(Comments comment)
        {
            _comments.AddComment(comment);
            return Created(HttpContext.Request.Scheme + "://" + HttpContext.Request.Host + HttpContext.Request.Path + "/" + comment.Id, comment);

        }

        [HttpDelete]
        [Route("api/[controller]/{id}")]
        public IActionResult DeleteComment(Guid id)
        {
            var commentToDelete = _comments.GetComment(id);
            if (commentToDelete != null)
            {
                _comments.DeleteComment(commentToDelete);
                return Ok("Deleted Comment with id:" + id);
            }
            return NotFound($"Comment with id:{id} was not found");

        }
        [HttpPut]
        [Route("api/[controller]/{id}")]
        public IActionResult UpdateComment(Guid id, Comments commentObj)
        {
            var existingComment = _comments.GetComment(id);
            if (existingComment != null)
            {
                commentObj.Id = existingComment.Id;
                _comments.UpdateComment(commentObj);
                return Ok(commentObj);
            }
            return NotFound($"Comment with id:{id} was not found");

        }
    }
}
