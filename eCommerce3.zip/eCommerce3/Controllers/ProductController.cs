﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using eCommerce3.Models;
using eCommerce3.ProductData;
using System;

namespace eCommerce3.Controllers
{

    [ApiController]
    public class ProductController : ControllerBase
    {
        private IProductData _productData;
        public ProductController(IProductData productData)
        {
            _productData = productData;
        }
        [HttpGet]
        [Route("api/[controller]")]
        public IActionResult GetProducts()
        {
            return Ok(_productData.GetProducts());
        }
        [HttpGet]
        [Route("api/[controller]/{id}")]
        public IActionResult GetProduct(Guid id)
        {
            var product = _productData.GetProduct(id);
            if (product != null)
            {
                return Ok(_productData.GetProduct(id));
            }
            return NotFound($"Product with id:{id} was not found");
        }
        [HttpPost]
        [Route("api/[controller]")]
        public CreatedResult AddProduct(ProductModel productModel)
        {
            _productData.AddProduct(productModel);
            return Created(HttpContext.Request.Scheme + "://" + HttpContext.Request.Host + HttpContext.Request.Path + "/" + productModel.Id, productModel);

        }

        [HttpDelete]
        [Route("api/[controller]/{id}")]
        public IActionResult DeleteProduct(Guid id)
        {
            var product = _productData.GetProduct(id);
            if (product != null)
            {
                _productData.DeleteProduct(product);
                return Ok("Deleted Product with id: " + id);
            }
            return NotFound($"Product with id:{id} was not found");

        }
        [HttpPut]
        [Route("api/[controller]/{id}")]
        public IActionResult UpdateProduct(Guid id, ProductModel productModel)
        {
            var existingProduct = _productData.GetProduct(id);
            if (existingProduct != null)
            {
                productModel.Id = existingProduct.Id;
                _productData.EditProduct(productModel);
                return Ok(productModel);
            }
            return NotFound($"Product with id:{id} was not found");

        }
    }
}
