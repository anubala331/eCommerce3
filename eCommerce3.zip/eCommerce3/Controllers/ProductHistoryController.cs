﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using eCommerce3.Models;
using eCommerce3.ProductHistoryData;
using System;

namespace eCommerce3.Controllers
{

    [ApiController]
    public class ProductHistoryController : ControllerBase
    {
        private IProductHistoryData _ProductHistoryData;
        public ProductHistoryController(IProductHistoryData ProductHistoryData)
        {
            _ProductHistoryData = ProductHistoryData;
        }
        [HttpGet]
        [Route("api/[controller]")]
        public IActionResult GetProductsHistory()
        {
            return Ok(_ProductHistoryData.GetProductsHistory());
        }
        [HttpGet]
        [Route("api/[controller]/{id}")]
        public IActionResult GetProductHistory(Guid id)
        {
            var ProductHistory = _ProductHistoryData.GetProductHistory(id);
            if (ProductHistory != null)
            {
                return Ok(_ProductHistoryData.GetProductHistory(id));
            }
            return NotFound($"ProductHistory with id:{id} was not found");
        }
        [HttpPost]
        [Route("api/[controller]")]
        public CreatedResult AddProductHistory(ProductHistoryModel ProductHistoryModel)
        {
            _ProductHistoryData.AddProductHistory(ProductHistoryModel);
            return Created(HttpContext.Request.Scheme + "://" + HttpContext.Request.Host + HttpContext.Request.Path + "/" + ProductHistoryModel.Id, ProductHistoryModel);

        }

        [HttpDelete]
        [Route("api/[controller]/{id}")]
        public IActionResult DeleteProductHistory(Guid id)
        {
            var ProductHistory = _ProductHistoryData.GetProductHistory(id);
            if (ProductHistory != null)
            {
                _ProductHistoryData.DeleteProductHistory(ProductHistory);
                return Ok("Deleted Product History with id:" + id);
            }
            return NotFound($"ProductHistory with id:{id} was not found");

        }
        [HttpPut]
        [Route("api/[controller]/{id}")]
        public IActionResult UpdateProductHistory(Guid id, ProductHistoryModel ProductHistoryModel)
        {
            var existingProductHistory = _ProductHistoryData.GetProductHistory(id);
            if (existingProductHistory != null)
            {
                ProductHistoryModel.Id = existingProductHistory.Id;
                _ProductHistoryData.EditProductHistory(ProductHistoryModel);
                return Ok(ProductHistoryModel);
            }
            return NotFound($"ProductHistory with id:{id} was not found");

        }
    }
}
