﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using eCommerce3.Models;
using eCommerce3.UserData;
using System;

namespace eCommerce3.Controllers
{

    [ApiController]
    public class UserController : ControllerBase
    {
        private IUserData _UserData;
        public UserController(IUserData UserData)
        {
            _UserData = UserData;
        }
        [HttpGet]
        [Route("api/[controller]")]
        public IActionResult GetUsers()
        {
            return Ok(_UserData.GetUsers());
        }
        [HttpGet]
        [Route("api/[controller]/{id}")]
        public IActionResult GetUser(Guid id)
        {
            var User = _UserData.GetUser(id);
            if (User != null)
            {
                return Ok(_UserData.GetUser(id));
            }
            return NotFound($"User with id:{id} was not found");
        }
        [HttpPost]
        [Route("api/[controller]")]
        public CreatedResult AddUser(UserModel UserModel)
        {
            _UserData.AddUser(UserModel);
            return Created(HttpContext.Request.Scheme + "://" + HttpContext.Request.Host + HttpContext.Request.Path + "/" + UserModel.Id, UserModel);

        }

        [HttpDelete]
        [Route("api/[controller]/{id}")]
        public IActionResult DeleteUser(Guid id)
        {
            var User = _UserData.GetUser(id);
            if (User != null)
            {
                _UserData.DeleteUser(User);
                return Ok("Deleted User with id:" + id);
            }
            return NotFound($"User with id:{id} was not found");

        }
        [HttpPut]
        [Route("api/[controller]/{id}")]
        public IActionResult UpdateUser(Guid id, UserModel UserModel)
        {
            var existingUser = _UserData.GetUser(id);
            if (existingUser != null)
            {
                UserModel.Id = existingUser.Id;
                _UserData.EditUser(UserModel);
                return Ok(UserModel);
            }
            return NotFound($"User with id:{id} was not found");

        }
    }
}
