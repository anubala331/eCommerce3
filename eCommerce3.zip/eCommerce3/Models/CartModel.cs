﻿using System;
using System.ComponentModel.DataAnnotations;

namespace eCommerce3.Models
{
    public class CartModel
    {
        [Key]
        public Guid Id { get; set; }
        public string userid { get; set; }
        public int quantity { get; set; }

       // public CartProductModel CartProducts { get; set; }
    }

    //public class CartProductModel
    //{
    //    [Key]
    //    public Guid Id { get; set; }
    //    public List<int> productid { get; set; }
    //}

}
