﻿using System;
using System.ComponentModel.DataAnnotations;

namespace eCommerce3.Models
{
    public class CartProductModel
    {
        [Key]
        public Guid Id { get; set; }
        public string cartid { get; set; }
        public string productid { get; set; }
    }
}
