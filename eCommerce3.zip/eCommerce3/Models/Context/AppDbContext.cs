﻿
using Microsoft.EntityFrameworkCore;

namespace eCommerce3.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
        public DbSet<UserModel> Users { get; set; }
        public DbSet<Comments> AllComments { get; set; }
        public DbSet<ProductModel> Products { get; set; }
        public DbSet<CartModel> Carts { get; set; }
        public DbSet<CartProductModel> CartProduct { get; set; }
        public DbSet<ProductHistoryModel> ProductHistory { get; set; }

    }
}
