﻿using eCommerce3.Models;
using System;
using System.Collections.Generic;

namespace eCommerce3.CartData
{
    public interface ICartData
    {
        List<CartModel> GetCarts();

        CartModel GetCart(Guid id);

        void DeleteCart(CartModel cart);

        CartModel EditCart(CartModel cart);

        CartModel AddCart(CartModel cart);
    }
}
