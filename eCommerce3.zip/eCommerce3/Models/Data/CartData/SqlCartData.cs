﻿using eCommerce3.Models;
using eCommerce3.CartData;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ecommerce3.CartData
{
    public class SqlCartData : ICartData
    {
        private AppDbContext context;
        public SqlCartData(AppDbContext context)
        {
            this.context = context;
        }
        public CartModel AddCart(CartModel Cart)
        {
            Cart.Id = Guid.NewGuid();
            context.Carts.Add(Cart);
            context.SaveChanges();
            return Cart;
        }

        public void DeleteCart(CartModel Cart)
        {
            context.Carts.Remove(Cart);
            context.SaveChanges();

        }
        public CartModel EditCart(CartModel Cart)
        {
            var existingCart = context.Carts.Find(Cart.Id);
            if (existingCart != null)
            {
                existingCart.userid = Cart.userid;
                existingCart.quantity = Cart.quantity;
                //existingCart.CartProducts.productid = Cart.CartProducts.productid;
                context.Carts.Update(existingCart);
                context.SaveChanges();
            }
            return Cart;
        }

        public CartModel GetCart(Guid id)
        {
            var Cart = context.Carts.Find(id);
            return Cart;
        }

        public List<CartModel> GetCarts()
        {
            return context.Carts.ToList();

        }
    }
}
