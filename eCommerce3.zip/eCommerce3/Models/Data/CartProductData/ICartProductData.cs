﻿using eCommerce3.Models;
using System;
using System.Collections.Generic;

namespace eCommerce3.CartData
{
    public interface ICartProductData
    {
        List<CartProductModel> GetCartProducts();

        CartProductModel GetCartProduct(Guid id);

        void DeleteCartProduct(CartProductModel cart);

        CartProductModel EditCartProduct(CartProductModel cart);

        CartProductModel AddCartProduct(CartProductModel cart);
    }
}
