﻿using eCommerce3.Models;
using eCommerce3.CartData;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ecommerce3.CartData
{
    public class SqlCartProductData : ICartProductData
    {
        private AppDbContext context;
        public SqlCartProductData(AppDbContext context)
        {
            this.context = context;
        }
        public CartProductModel AddCartProduct(CartProductModel Cart)
        {
            Console.WriteLine("Going to Add Cart Product sql");
            Cart.Id = Guid.NewGuid();
            Console.WriteLine("Going to Add Cart Product with id" + Cart.Id);
            context.CartProduct.Add(Cart);
            context.SaveChanges();
            return Cart;
        }

        public void DeleteCartProduct(CartProductModel Cart)
        {
            context.CartProduct.Remove(Cart);
            context.SaveChanges();

        }
        public CartProductModel EditCartProduct(CartProductModel Cart)
        {
            var existingCart = context.CartProduct.Find(Cart.Id);
            if (existingCart != null)
            {
                existingCart.cartid = Cart.cartid;
                existingCart.productid = Cart.productid;
                context.CartProduct.Update(existingCart);
                context.SaveChanges();
            }
            return Cart;
        }

        public CartProductModel GetCartProduct(Guid id)
        {
            var Cart = context.CartProduct.Find(id);
            return Cart;
        }

        public List<CartProductModel> GetCartProducts()
        {
            return context.CartProduct.ToList();

        }
    }
}
