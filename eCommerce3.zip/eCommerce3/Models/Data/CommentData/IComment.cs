﻿using System;
using System.Collections.Generic;
using eCommerce3.Models;

namespace eCommerce3.Models
{
    public interface IComment
    {
        List<Comments> GetAllComments();
        Comments GetComment(Guid id);
        Comments AddComment(Comments comment);
        void DeleteComment(Comments comment);
        Comments UpdateComment(Comments comment);
    }
}