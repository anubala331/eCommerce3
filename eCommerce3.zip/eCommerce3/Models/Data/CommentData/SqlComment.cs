﻿using eCommerce3.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ecommerce3.Models
{
    public class SqlComment : IComment
    {
        private AppDbContext context;
        public SqlComment(AppDbContext context)
        {
            this.context = context;
        }

        public Comments AddComment(Comments comment)
        {
            comment.Id = Guid.NewGuid();
            context.AllComments.Add(comment);
            context.SaveChanges();
            return comment;
        }

        public void DeleteComment(Comments comment)
        {


            context.AllComments.Remove(comment);
            context.SaveChanges();

        }

        public Comments UpdateComment(Comments commentObj)
        {
            var existingComment = context.AllComments.Find(commentObj.Id);
            if (existingComment != null)
            {
                existingComment.Comment = commentObj.Comment;
                existingComment.Rating = commentObj.Rating;
                existingComment.Image = commentObj.Image;
                context.AllComments.Update(existingComment);
                context.SaveChanges();
            }
            return commentObj;
        }

        public Comments GetComment(Guid id)
        {
            var comment = context.AllComments.Find(id);
            return comment;
        }

        public List<Comments> GetAllComments()
        {
            return context.AllComments.ToList();

        }
    }
}
