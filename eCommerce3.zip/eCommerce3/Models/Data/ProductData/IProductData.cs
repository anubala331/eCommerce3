﻿using eCommerce3.Models;
using System;
using System.Collections.Generic;

namespace eCommerce3.ProductData
{
    public interface IProductData
    {
        List<ProductModel> GetProducts();

        ProductModel GetProduct(Guid id);

        ProductModel AddProduct(ProductModel product);

        void DeleteProduct(ProductModel product);
        ProductModel EditProduct(ProductModel product);
    }
}
