﻿using eCommerce3.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using eCommerce3.ProductData;

namespace ecommerce3.ProductData
{
    public class SqlProductData : IProductData
    {
        private AppDbContext context;
        public SqlProductData(AppDbContext context)
        {
            this.context = context;
        }
        public ProductModel AddProduct(ProductModel product)
        {
                product.Id = Guid.NewGuid();
                context.Products.Add(product);
                context.SaveChanges();
                return product;
        }

        public void DeleteProduct(ProductModel product)
        {
            
                context.Products.Remove(product);
                context.SaveChanges();
        }

        public ProductModel EditProduct(ProductModel product)
        {
            var existingProduct = context.Products.Find(product.Id);
            if(existingProduct != null)
            {
                existingProduct.productname = product.productname;
                existingProduct.brandname = product.brandname;
                existingProduct.Pricing = product.Pricing;
                existingProduct.shippingcost = product.shippingcost;
                existingProduct.Description = product.Description;
                existingProduct.Image = product.Image;
                context.Products.Update(existingProduct);
                context.SaveChanges();
            }
            return product;
        }

        public ProductModel GetProduct(Guid id)
        {
            var product = context.Products.Find(id);
            return product;
        }

        public List<ProductModel> GetProducts()
        {
            return context.Products.ToList();
           
        }
    }
}
