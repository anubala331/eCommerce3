﻿using eCommerce3.Models;
using System;
using System.Collections.Generic;

namespace eCommerce3.ProductHistoryData
{
    public interface IProductHistoryData
    {
        List<ProductHistoryModel> GetProductsHistory();

        ProductHistoryModel GetProductHistory(Guid id);

        void DeleteProductHistory(ProductHistoryModel ProductHistory);

        ProductHistoryModel EditProductHistory(ProductHistoryModel ProductHistory);

        ProductHistoryModel AddProductHistory(ProductHistoryModel ProductHistory);
    }
}
