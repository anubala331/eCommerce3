﻿using eCommerce3.Models;
using eCommerce3.ProductHistoryData;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ecommerce3.ProductHistoryData
{
    public class SqlProductHistoryData : IProductHistoryData
    {
        private AppDbContext context;
        public SqlProductHistoryData(AppDbContext context)
        {
            this.context = context;
        }
        public ProductHistoryModel AddProductHistory(ProductHistoryModel ProductHistory)
        {
            ProductHistory.Id = Guid.NewGuid();
            context.ProductHistory.Add(ProductHistory);
            context.SaveChanges();
            return ProductHistory;
        }

        public void DeleteProductHistory(ProductHistoryModel ProductHistory)
        {
            context.ProductHistory.Remove(ProductHistory);
            context.SaveChanges();

        }
        public ProductHistoryModel EditProductHistory(ProductHistoryModel ProductHistory)
        {
            var existingProductHistory = context.ProductHistory.Find(ProductHistory.Id);
            if (existingProductHistory != null)
            {
                existingProductHistory.productid = ProductHistory.productid;
                existingProductHistory.userid = ProductHistory.userid;
                existingProductHistory.brand = ProductHistory.brand;
                existingProductHistory.productname = ProductHistory.productname;
                context.ProductHistory.Update(existingProductHistory);
                context.SaveChanges();
            }
            return ProductHistory;
        }

        public ProductHistoryModel GetProductHistory(Guid id)
        {
            var ProductHistory = context.ProductHistory.Find(id);
            return ProductHistory;
        }

        public List<ProductHistoryModel> GetProductsHistory()
        {
            return context.ProductHistory.ToList();

        }
    }
}
