using eCommerce3.Models;
using System;
using System.Collections.Generic;

namespace eCommerce3.UserData
{
    public interface IUserData
    {
        List<UserModel> GetUsers();

        UserModel GetUser(Guid id);

        void DeleteUser(UserModel user);
       
        UserModel EditUser(UserModel user);

        UserModel AddUser(UserModel user);
    }
}
