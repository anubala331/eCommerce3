using eCommerce3.Models;
using eCommerce3.UserData;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ecommerce3.UserData
{
    public class SqlUserData : IUserData
    {
        private AppDbContext context;
        public SqlUserData(AppDbContext context)
        {
            this.context = context;
        }
        public UserModel AddUser(UserModel User)
        {
            User.Id = Guid.NewGuid();
            context.Users.Add(User);
            context.SaveChanges();
            return User;
        }

        public void DeleteUser(UserModel User)
        {
            context.Users.Remove(User);
            context.SaveChanges();

        }
        public UserModel EditUser(UserModel User)
        {
            var existingUser = context.Users.Find(User.Id);
            if (existingUser != null)
            {
                existingUser.FirstName = User.FirstName;
                existingUser.LastName = User.LastName;
                existingUser.UserName = User.UserName;
                existingUser.Email = User.Email;
                existingUser.Shipping_Address = User.Shipping_Address;
                existingUser.Password = User.Password;
                context.Users.Update(existingUser);
                context.SaveChanges();
            } else
            {
                Console.WriteLine("Existing object is null, cannot update user");
            }
            return User;
        }

        public UserModel GetUser(Guid id)
        {
            var User = context.Users.Find(id);
            return User;
        }

        public List<UserModel> GetUsers()
        {
            return context.Users.ToList();

        }
    }
}
