﻿using System;
using System.ComponentModel.DataAnnotations;

namespace eCommerce3.Models
{
    public class ProductHistoryModel
    {
        [Key]
        public Guid Id { get; set; }
        public int productid { get; set; }
        public int userid { get; set; }
        public string brand { get; set; }
        public string productname { get; set; }

    }
}
