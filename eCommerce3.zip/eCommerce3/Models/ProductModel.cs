﻿using System;
using System.ComponentModel.DataAnnotations;

namespace eCommerce3.Models
{
    public class ProductModel
    {
        [Key]
        public Guid Id { get; set; } 
        public string productname { get; set; } 
        public string brandname { get; set; }
        public string Image { get; set; }
        public double Pricing { get; set; }
        public double shippingcost { get; set; }
        public string Description { get; set; }

    }
}
