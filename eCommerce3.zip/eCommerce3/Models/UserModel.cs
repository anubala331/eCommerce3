using System;
using System.ComponentModel.DataAnnotations;

namespace eCommerce3.Models
{
    public class UserModel
    {
        [Key]
        public Guid Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string UserName { get; set; }
        public string Email { get; set; }
        public string Shipping_Address { get; set; }
        public string Password { get; set; }

    }
}
