using eCommerce3.Models;
using Microsoft.EntityFrameworkCore;
using eCommerce3.UserData;
using ecommerce3.UserData;
using eCommerce3.ProductData;
using ecommerce3.ProductData;
using eCommerce3.ProductHistoryData;
using ecommerce3.ProductHistoryData;
using eCommerce3.CartData;
using ecommerce3.CartData;
using ecommerce3.Models;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
//builder.Services.AddDbContext<AppDbContext>(opts => opts.UseInMemoryDatabase("MemoryDB"));
Console.WriteLine("inside Program.cs-------------");
//Console.WriteLine("AppDbContextConnectionString" + AppDbContextConnectionString);
//services.AddDbContextPool<AppDbContext>(options => options.UseSqlServer(Configuration.GetConnectionString("AppDbContextConnectionString")));
//services.AddScoped<IProductData, SqlProductData>();
//   }
builder.Services.AddMvc();
builder.Services.AddDbContext<AppDbContext>(opts => opts.UseSqlServer(builder.Configuration.GetConnectionString("AppDbContextConnectionString"))); //connectionString: "AppDbContextConnectionString"
builder.Services.AddTransient<IUserData, SqlUserData>();
builder.Services.AddTransient<IProductData, SqlProductData>();
builder.Services.AddTransient<IProductHistoryData, SqlProductHistoryData>();
builder.Services.AddTransient<IComment, SqlComment>();
builder.Services.AddTransient<ICartData, SqlCartData>();
builder.Services.AddTransient<ICartProductData, SqlCartProductData>();

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthorization();

app.MapControllers();

app.Run();
